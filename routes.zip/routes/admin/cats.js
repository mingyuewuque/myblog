var express = require('express');
var Objectid= require('Objectid');
var router = express.Router();
var Mongoclient=require('mongodb').MongoClient;
const url='mongodb://localhost:27017/blog'

/* GET home page. */
router.get('/', function(req, res, next) {
    res.render('admin/cats', { title: 'Express' });
});

router.get('/add', function(req, res, next) {

    res.render('admin/category_add');
});

router.get('/list', function(req, res, next) {
    Mongoclient.connect(url,(err,db)=>{
        if(err) throw err;
        let lists=db.collection('lists');
        lists.find().toArray((err,result)=>{
            if(err) throw err;
            res.render('admin/category_list',{data:result});
        })
    })

});

router.post('/insert', function(req, res, next) {
    Mongoclient.connect(url,(err,db)=>{
        if(err) throw err;
        let msg='1';
        let lists=db.collection('lists');
        lists.insert(req.body,(err,result)=>{
            if(err){
                msg='添加分类失败';
            }else{
              msg='添加分类成功';
            }
            res.render('admin/msg',{data:msg});
            //res.render('admin/msg');
        })
    })

});

router.get('/delete', function(req, res, next) {

    Mongoclient.connect(url,(err,db)=>{
        if(err) throw err;
        let msg='';
        let lists=db.collection('lists');
        let id=req.query.oid;
        lists.remove({_id:Objectid(id)},(err,result)=>{
            if(err){
                msg='删除信息失败';
            }else{
                msg='删除信息成功';
            }
            res.render('admin/msg',{data:msg});
        })
    })
});

router.get('/edit', function(req, res, next) {
    Mongoclient.connect(url,(err,db)=> {
        let lists = db.collection('lists');
        let id = req.query.oid;
        lists.find({_id:Objectid(id)}).toArray((err,result)=>{
           if(err) throw err;
            console.log(result)
            res.render('admin/category_edit',{content:result})
        })
    });

})

router.post('/update', (req, res, next)=>{
    let msg='';
    Mongoclient.connect(url,(err,db)=> {
        if(err) throw err;

        let lists = db.collection('lists');
        let id = req.body.oid;
        let title = req.body.title;
        let order = req.body.order;
        console.log(req.body)
        lists.update({_id: Objectid(id)}, {$set: {title:title}},(err, result)=>{
            if(err) throw err;

            if (err) {
                msg = '更新信息失败';
            } else {
                msg = '更新信息成功';
            }
            res.render('admin/msg', {data: msg});
        })


    });
});
module.exports = router;
