var express = require('express');
var router = express.Router();
var Objectid= require('Objectid');
const fs=require('fs')
var multiparty=require('multiparty');
var Mongoclient=require('mongodb').MongoClient;
const url='mongodb://localhost:27017/blog'

/* GET home page. */
router.get('/', function(req, res, next) {
    Mongoclient.connect(url,(err,db)=>{
        let articles=db.collection('articles');
        articles.find().toArray((err,result)=>{
            res.render('admin/article_list',{data:result});
        })

    });

});

router.get('/add', function(req, res, next) {
    Mongoclient.connect(url,(err,db)=>{
        let lists=db.collection('lists');
        lists.find().toArray((err,result)=>{
            res.render('admin/article_add',{data:result});
        })
    })

});

router.get('/delete', function(req, res, next) {
    Mongoclient.connect(url,(err,db)=>{
        if(err) throw err;
        let msg='';
        let articles=db.collection('articles');
        let id=req.query.oid;
        articles.remove({_id:Objectid(id)},(err,result)=>{
            if(err){
                msg='删除信息失败';
            }else{
                msg='删除信息成功';
            }
            res.render('admin/msg',{data:msg});
        })
    })

});

router.post('/insert',(req,res)=>{
    let form=new multiparty.Form();
    form.parse(req,(err,fields,files)=>{
        //console.log(fields)
        //console.log(files)
        let list=fields.cat[0];
        let dstPath = './public/files/' + files.cover[0].originalFilename;
        fs.renameSync(files.cover[0].path,dstPath);
        let data={
            cats:fields,
            filepath:'/files/' + files.cover[0].originalFilename,
            date:new Date(),
            count:Math.floor(Math.random()*100+20),
            list:list
        };
        Mongoclient.connect(url,(err,db)=>{
            let articles=db.collection('articles');
            articles.insert(data,(err,result)=>{
                if(err){
                    msg='添加文章失败';
                }else{
                    msg='添加文章成功';
                }
                res.render('admin/msg',{data:msg});
            });


        });
    });



});

module.exports = router;