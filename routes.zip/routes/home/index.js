var express = require('express');
var router = express.Router();
var Mongoclient=require('mongodb').MongoClient;
const markdown = require('markdown').markdown;
const url='mongodb://localhost:27017/blog';
/* GET home page. */
router.get('/', function(req, res, next) {
  Mongoclient.connect(url,(err,db)=>{
    let lists=db.collection('lists');
    lists.find().toArray((err,res1)=>{
      if(err) throw err;
      let articles=db.collection('articles');
      articles.find().toArray((err,res2)=>{
        if(err) throw err;
        articles.find().sort({count:-1}).toArray((err,res3)=>{

          let data={
            res1:res1,
            res2:res2,
            sorts:res3
          };

          res.render('home/index',{data:data});
        });

      });

    });
  });

});

module.exports = router;
